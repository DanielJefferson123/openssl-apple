#ifndef MC_WRAPPER_H
# define MC_WRAPPER_H

#include "mcapi.h"

int load_mc(const char* pLibPath);
	
extern fn_MC_OpenSession		pRealMC_OpenSession;
extern fn_MC_CloseSession		pMC_CloseSession;
extern fn_MC_CopySession		pMC_CopySession;
extern fn_MC_SetOption			pMC_SetOption;
extern fn_MC_CreateObject		pMC_CreateObject;
extern fn_MC_Decrypt			pMC_Decrypt;
extern fn_MC_DecryptInit		pMC_DecryptInit;
extern fn_MC_DestroyObject		pMC_DestroyObject;
extern fn_MC_DigestFinal		pMC_DigestFinal;
extern fn_MC_DigestInit			pMC_DigestInit;
extern fn_MC_DigestUpdate		pMC_DigestUpdate;
extern fn_MC_Encrypt			pMC_Encrypt;
extern fn_MC_EncryptInit		pMC_EncryptInit;
extern fn_MC_GenerateKey		pMC_GenerateKey;
extern fn_MC_GenerateKeyPair	pMC_GenerateKeyPair;
extern fn_MC_DeriveKey			pMC_DeriveKey;
extern fn_MC_GenerateRandom		pMC_GenerateRandom;
extern fn_MC_GetObjectValue		pMC_GetObjectValue;
extern fn_MC_Sign				pMC_Sign;
extern fn_MC_SignInit			pMC_SignInit;
extern fn_MC_Verify				pMC_Verify;
extern fn_MC_VerifyInit			pMC_VerifyInit;

#endif // MC_WRAPPER_H
