#if defined(linux) || defined(__linux) || defined(__linux__)
#include <dlfcn.h>
#define GetProcAddress dlsym
#define LIB_NAME "libMagicCrypto.so"
#elif defined(_WIN32)
#include <windows.h>
#define LIB_NAME "MagicCryptoV22.dll"
#elif __APPLE__
#include <dlfcn.h>
#define GetProcAddress dlsym
#define LIB_NAME "libMagicCrypto.dylib"
#endif

#include <stdio.h>
#include <string.h>

#include "mcapi.h"

fn_MC_OpenSession		pRealMC_OpenSession = 0;
fn_MC_CloseSession		pMC_CloseSession = 0;
fn_MC_CopySession		pMC_CopySession = 0;
fn_MC_SetOption			pMC_SetOption = 0;
fn_MC_CreateObject		pMC_CreateObject = 0;
fn_MC_Decrypt			pMC_Decrypt = 0;
fn_MC_DecryptInit		pMC_DecryptInit = 0;
fn_MC_DecryptUpdate		pMC_DecryptUpdate = 0;
fn_MC_DecryptFinal		pMC_DecryptFinal = 0;
fn_MC_DestroyObject		pMC_DestroyObject = 0;
fn_MC_DigestFinal		pMC_DigestFinal = 0;
fn_MC_DigestInit		pMC_DigestInit = 0;
fn_MC_DigestUpdate		pMC_DigestUpdate = 0;
fn_MC_Encrypt			pMC_Encrypt = 0;
fn_MC_EncryptInit		pMC_EncryptInit = 0;
fn_MC_EncryptUpdate		pMC_EncryptUpdate = 0;
fn_MC_EncryptFinal		pMC_EncryptFinal = 0;
fn_MC_GenerateKey		pMC_GenerateKey = 0;
fn_MC_GenerateKeyPair	pMC_GenerateKeyPair = 0;
fn_MC_DeriveKey			pMC_DeriveKey = 0;
fn_MC_GenerateRandom	pMC_GenerateRandom = 0;
fn_MC_GetObjectValue	pMC_GetObjectValue = 0;
fn_MC_Sign				pMC_Sign = 0;
fn_MC_SignInit			pMC_SignInit = 0;
fn_MC_Verify			pMC_Verify = 0;
fn_MC_VerifyInit		pMC_VerifyInit = 0;

void* mc_lib_handle = 0;

int load_mc(const char* pLibPath)
{
    if (pRealMC_OpenSession != 0)
	{
        return 0;
	}

    char szLibPath[0x100];
    strcpy(szLibPath, pLibPath);
    strcat(szLibPath, LIB_NAME);

#if defined(linux) || defined(__linux) || defined(__linux__)
	mc_lib_handle = dlopen(szLibPath, RTLD_LAZY);
#elif defined(_WIN32)
	mc_lib_handle = (HMODULE)LoadLibraryA(szLibPath);
#elif __APPLE__
	mc_lib_handle = dlopen(szLibPath, RTLD_LAZY);
#endif

	if (mc_lib_handle == 0)
	{
		printf("failed to load " LIB_NAME ".");
		return 0;
	}

	pRealMC_OpenSession = (fn_MC_OpenSession)GetProcAddress(mc_lib_handle, "MC_OpenSession");
	if (pMC_OpenSession == 0)
	{
		printf("failed to get MC_OpenSession function.");
		return 0;
	}
		
	pMC_CloseSession = (fn_MC_CloseSession)GetProcAddress(mc_lib_handle, "MC_CloseSession");
	pMC_CopySession = (fn_MC_CopySession)GetProcAddress(mc_lib_handle, "MC_CopySession");
	pMC_SetOption = (fn_MC_SetOption)GetProcAddress(mc_lib_handle, "MC_SetOption");
	pMC_CreateObject = (fn_MC_CreateObject)GetProcAddress(mc_lib_handle, "MC_CreateObject");
	pMC_Decrypt = (fn_MC_Decrypt)GetProcAddress(mc_lib_handle, "MC_Decrypt");
	pMC_DecryptInit = (fn_MC_DecryptInit)GetProcAddress(mc_lib_handle, "MC_DecryptInit");
	pMC_DecryptUpdate = (fn_MC_DecryptUpdate)GetProcAddress(mc_lib_handle, "MC_DecryptUpdate");
	pMC_DecryptFinal = (fn_MC_DecryptFinal)GetProcAddress(mc_lib_handle, "MC_DecryptFinal");
	pMC_DestroyObject = (fn_MC_DestroyObject)GetProcAddress(mc_lib_handle, "MC_DestroyObject");
	pMC_DigestFinal = (fn_MC_DigestFinal)GetProcAddress(mc_lib_handle, "MC_DigestFinal");
	pMC_DigestInit = (fn_MC_DigestInit)GetProcAddress(mc_lib_handle, "MC_DigestInit");
	pMC_DigestUpdate = (fn_MC_DigestUpdate)GetProcAddress(mc_lib_handle, "MC_DigestUpdate");
	pMC_Encrypt = (fn_MC_Encrypt)GetProcAddress(mc_lib_handle, "MC_Encrypt");
	pMC_EncryptInit = (fn_MC_EncryptInit)GetProcAddress(mc_lib_handle, "MC_EncryptInit");
	pMC_EncryptUpdate = (fn_MC_EncryptUpdate)GetProcAddress(mc_lib_handle, "MC_EncryptUpdate");
	pMC_EncryptFinal = (fn_MC_EncryptFinal)GetProcAddress(mc_lib_handle, "MC_EncryptFinal");
	pMC_GenerateKey = (fn_MC_GenerateKey)GetProcAddress(mc_lib_handle, "MC_GenerateKey");
	pMC_GenerateKeyPair = (fn_MC_GenerateKeyPair)GetProcAddress(mc_lib_handle, "MC_GenerateKeyPair");
	pMC_DeriveKey = (fn_MC_DeriveKey)GetProcAddress(mc_lib_handle, "MC_DeriveKey");
	pMC_GenerateRandom = (fn_MC_GenerateRandom)GetProcAddress(mc_lib_handle, "MC_GenerateRandom");
	pMC_GetObjectValue = (fn_MC_GetObjectValue)GetProcAddress(mc_lib_handle, "MC_GetObjectValue");
	pMC_Sign = (fn_MC_Sign)GetProcAddress(mc_lib_handle, "MC_Sign");
	pMC_SignInit = (fn_MC_SignInit)GetProcAddress(mc_lib_handle, "MC_SignInit");
	pMC_Verify = (fn_MC_Verify)GetProcAddress(mc_lib_handle, "MC_Verify");
	pMC_VerifyInit = (fn_MC_VerifyInit)GetProcAddress(mc_lib_handle, "MC_VerifyInit");
	
	return 1;
}


MC_RV pMC_OpenSession(OUT MC_HSESSION *phSession)
{
	if (pRealMC_OpenSession == NULL)
	{
		char szExePath[0x100] = { 0 };
#if defined(linux) || defined(__linux) || defined(__linux__)
		
#elif defined(_WIN32)
		GetModuleFileNameA(NULL, szExePath, _MAX_PATH);
		*(strrchr(szExePath, '\\') + 1) = 0;
#endif
		if (load_mc(szExePath) == 0)
			return MC_FAIL;
	}
	
	return	pRealMC_OpenSession(phSession);
}

